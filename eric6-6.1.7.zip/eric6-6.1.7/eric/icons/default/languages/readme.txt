Icons where downloaded from official sites of the languages and various other places.
